// import axios from 'axios';

// const  OFFICE_API_BASE_URL = "http://localhost:9191/api/ocma/customer";

// class CustomerService {
// addCustomer(customer){
//     return axios.post(CUSTOMER_API_BASE_URL, customer);
// }
// }
